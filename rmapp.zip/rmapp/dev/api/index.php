<!DOCTYPE html>
<html>
<head>
   <title></title>
</head>
<body>
<pre>
<b>Registaration API</b>
URL ::: http://reminderapi.mobile-codingbrains.com/api/registrationApi.php
Request ::: {"name":"rajeshkumar","email":"codingbrains06@gmail.com","password":"test@123"}
<hr>
<b>Login API</b>
URL  ::: http://reminderapi.mobile-codingbrains.com/api/loginApi.php
Request ::: {"email":"codingbrains06@gmail.com","password":"test@123"}
<hr>
<b>User List</b>
URL  :::  http://reminderapi.mobile-codingbrains.com/api/userListApi.php
<hr>
codingbr_user
tek69CnKzCGG
ftp.mobile-codingbrains.com
reminderapi@reminderapi.mobile-codingbrains.com
LI4x2=XpSWsb
Note ::::  Please add this details to google doc. 
</pre>
</body>
</html>
