<?php 
//Parameters{fname,lname,name,email,password}
$postdata = file_get_contents("php://input");
require_once ("DbConnection.php");
$db_handle = new DBConnection();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
header('Content-Type: application/json; charset=UTF-8');
//header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 86400'); 
$request = json_decode($postdata);





$fname = "cron";
$lname = "job";
$name = "test cron job";
$password ="test123";
$email = "cron@g.com";
$status = "Active";
$timeZone = date_default_timezone_get();
//$timeZone = $timeZone;
$currentDate =  date("Y/m/d");
$loginCount = 0;
if(!empty($name) && !empty($email) && !empty($password)){
    $query = "INSERT INTO `registration` (`id`, `fname`, `lname`, `userName`, `userPassword`, `userEmail`, `status`, `created_at`, `timeZone`, `updated_at`) VALUES (NULL, '".$fname."', '".$lname."' , '".$name."', '".$password."', '".$email."', '".$status."', '".$currentDate."', '".$timeZone."', '')";
    $results = $db_handle->insertQuery($query);
    if($results == true){
    	$query = "INSERT INTO `login` (`id`, `userName`, `userPassword`, `userEmail`, `status`, `created_at`, `loginCount`, `updated_at`) VALUES (NULL, '".$name."', '".$password."', '".$email."', '".$status."', '".$currentDate."', '".$loginCount."', '')";
    	$results = $db_handle->insertQuery($query);
    	if($results == true){
        	$msg = array('status'=>"200",'message' => "Success");
    	}else{

    	}
    }else{
        $msg =array('status'=>"204",'message' => "fails");
    }
}
echo json_encode($msg);?>