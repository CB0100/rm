<?php 
$postdata = file_get_contents("php://input");
require_once ("DbConnection.php");
$db_handle = new DBConnection();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
header('Content-Type: application/json; charset=UTF-8');
//header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 86400'); 
$request = json_decode($postdata);
//Email validation
if(!empty($request->email)){
	if(!preg_match("/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/",$request->email)){
        $msg = array('status'=>"204",'message' => "Invalid Email Id");
    }else{
        $email = $request->email;
    }
}else{
    $msg = array('status'=>"204",'message' => "Email Field can't empty");
}
//Password validation
if(!empty($request->password)){
    $password = md5($request->password);
    $password1 = $request->password;
}else{
    $msg = array('status'=>"204",'message' => "Password Field can't empty");
}
$query = "SELECT `id` FROM `login` WHERE `userEmail`='".$email."'";

$results = $db_handle->numRows($query);

if ($results > 0) {
	$sql_qry = "UPDATE `registration` SET `userPassword`='".$password."' WHERE `userEmail`='".$email."'";
    $res = $db_handle->updateQuery($sql_qry);
    if($res == true){
        $sql_qury = "UPDATE `login` SET `userPassword`='".$password."' WHERE `userEmail`='".$email."'";
        $result = $db_handle->updateQuery($sql_qry);
        if($result == true){
            $msg = array('status'=>"200",'message' => "Password changed successfully",'email' => $email);
        }else{
            $msg = array('status'=>"204",'message' => "Password has not changed",'email' => $email);
        }
    }
}else{
	$msg = array('status'=>"204",'message' => "Email Id does not exists",'email' => $email);
}
echo json_encode($msg);?>
