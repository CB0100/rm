<?php
    // Update after user reponse(accept/reject)
    //Parameters{userId,action,msg_id}
    $postdata = file_get_contents("php://input");
    
	require_once ("DbConnection.php");
	$db_handle = new DBConnection();
    
    header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
	header('Content-Type: application/json; charset=UTF-8');
	header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); 
    
    $request = json_decode($postdata);
    
    $user_id=$request->userId;  // user_id
    $action=$request->action;   // action
    $action=(int)$action;       // converting action value to int
    $msg_id=$request->msg_id;   // msg_id
    
    if($action==1)          // Action value 1 means user rejected the notification
        {
            $query = "UPDATE notification SET status='Rejected' WHERE user_id='$user_id' AND msg_id='$msg_id'";
            $results = $db_handle->updateQuery($query);
            if($results==="Updated successfully")
                {
                    $msg = array('status'=>"200",'message' => "Rejected",'id' => $user_id);
                }
        }
    else if($action==0)     // Action value 0 means user accepted the notification
        {
            $query2 = "UPDATE notification SET status='Accepted' WHERE user_id='$user_id' AND msg_id='$msg_id'";
            $results2 = $db_handle->updateQuery($query2);
            if($results2==="Updated successfully")
                {
                    $msg = array('status'=>"200",'message' => "Accepted",'id' => $user_id);
                }            
        }
    else
        {
            $msg = array('status'=>"204",'message' => "Error",'id' => $user_id);
        }
    echo json_encode($msg);
?>