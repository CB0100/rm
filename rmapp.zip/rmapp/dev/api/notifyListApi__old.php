<?php
	// Showing list of users to which notification is sent.
	//Parameter{userId}
	$postdata = file_get_contents("php://input");

	require_once ("DbConnection.php");
	$db_handle = new DBConnection();
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
	header('Content-Type: application/json; charset=UTF-8');
	header('Access-Control-Allow-Credentials: true');
	header('Access-Control-Max-Age: 86400'); 
	
	$request = json_decode($postdata);
	
	$user_id=$request->userId;
	
	$query = "SELECT * FROM `notification` WHERE user_id=$user_id";
	$res = $db_handle->runQuery($query);
	
	echo json_encode($res);
?>