<?php
	// Updating user status and pushing notification
	//parameters: {sender_id,id,startsTime,endTime,remarks,token}
	$postdata = file_get_contents("php://input");
	require_once ("DbConnection.php");
	$db_handle = new DBConnection();
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
	header('Content-Type: application/json; charset=UTF-8');
	//header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
	header('Access-Control-Allow-Credentials: true');
	header('Access-Control-Max-Age: 86400'); 
	$request = json_decode($postdata);	
	$msg="";
	$sender_id=$request->sender_id;	
	$sender_id=(int)$sender_id;
	$user_id=$request->id;
	$user_id=(int)$user_id;
	$startsTime=$request->startsTime;		
	$endTime=$request->endTime;		
	$remarks=$request->remarks;		

	// Function for push notification
	function sendPushNotification($to='',$data=array())
		{
			// Legacy key in Firebase from Project -> Settings icon -> Cloud messaging
			$apiKey = 'AIzaSyAAnmxUaiOfS5VVZf_HA-nu1Ch4I3ljQ_Y'; // For reminderApi project on firebase
			//$apiKey = 'AIzaSyB_kPgeb8VhaK0R5NHmOkO0ygzhBDnAY4Q'; // For codingbrains56 project on firebase
			$fields = array('to'=>$to,'notification'=>$data);
			$headers=array('Authorization:key='.$apiKey,'Content-Type:application/json');
			$url = 'https://fcm.googleapis.com/fcm/send';
			$ch = curl_init(); 
			// Set the url, number of POST vars, POST data
			curl_setopt($ch, CURLOPT_URL, $url); 
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
			// Execute post   
			$result = curl_exec($ch); 
			// Close connection      
			curl_close($ch);
			return json_decode($result,true);
		}

	// Getting device token on the basis of user id for sending notification on that device
	$query1 = "SELECT device_token FROM `registration` WHERE id=$user_id";
	$res1 = $db_handle->runQuery($query1);
	$dt=$res1[0];
	$to=$dt['device_token'];  // Getting device token
	// Preparing message and type of message
	$data=array('body'=>$remarks,'vibrate' => 1,'title' => 'New message','sound' => 1);
	$message_sent=$data['body'];

	if($msg=="")
		{		
			$suc=sendPushNotification($to,$data);  // Sending notification

			$t=$suc['results'][0];
			// inserting data after notifying
			$query2 = "INSERT INTO `notification` (`sender_id`,`user_id`, `msg_id`, `message`, `status`,`start_time`,`end_time`) VALUES ('$sender_id','$user_id', '".$t['message_id']."' , '".$message_sent."', 'Pending' , '".$startsTime."', '".$endTime."')";
			$results2 = $db_handle->insertQuery($query2);
			if($results2 === "New record created successfully")
				{
					$msg = array('status'=>"200",'message' => $remarks,'reciever_id' => $user_id,'sender_id'=>$sender_id,'notified'=>$suc['success'],'message_id'=>$t['message_id'],'status'=>'Pending');
				}
			else
				{
					$msg = array('status'=>"204",'message' => "Updation fails",'id' => $user_id);
				}				    
			echo json_encode($msg);
	    }	    	
?>