<?php
	//wget http://reminderapi.mobile-codingbrains.com/api/change_status.php
	// This api is used to set status as Accepted in notification table when current time is in between start time and end time

	$postdata = file_get_contents("php://input");

	require_once ("DbConnection.php");
	$db_handle = new DBConnection();

	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
	header('Content-Type: application/json; charset=UTF-8');
	header('Access-Control-Allow-Credentials: true');
	header('Access-Control-Max-Age: 86400'); 

	$request = json_decode($postdata);
	$reg_query = "SELECT n.start_time,n.end_time,n.user_id,n.msg_id, r.timeZone from notification n left join registration r on r.id = n.user_id";
	$res = $db_handle->runQuery($reg_query);
	
	for($i=0;$i<count($res);$i++)
				{
					$rest=$res[$i];
					
					$strt_time=$rest['start_time'];		//start time
					$end_time=$rest['end_time'];		//end time
					$usrid=$rest['user_id'];			//user id
					$mid=$rest['msg_id'];				//msg id
					$user_timezone=$rest['timezone'];	// time zone
					
					date_default_timezone_set($user_timezone); // setting default time zone to user's timezone
					$currentTime = date('Y-m-d h:i:s', time());

					$ct=date('Y-m-d h:i:s', strtotime($currentTime));	// Getting current time on the basis of user's time zone
					$contractDateBegin = date('Y-m-d h:i:s', strtotime($strt_time));
					$contractDateEnd = date('Y-m-d h:i:s', strtotime($end_time));

					if (($ct > $contractDateBegin) && ($ct < $contractDateEnd)){	// Checking if current time is in betweent the start time and end time
						$query = "UPDATE notification SET status='Accepted' WHERE msg_id='$mid'"; // updating status to Accepted in notification table
						$results = $db_handle->updateQuery($query);	
					}
					else{
						$query2 = "UPDATE notification SET status='Pending' WHERE msg_id='$mid'";	// updating status to Pending in notification table
						$results2 = $db_handle->updateQuery($query2);
					}
				} 
?>