<?php
	// Showing list of users to which notification is sent.
	//Parameter{userId}
	$postdata = file_get_contents("php://input");

	require_once ("DbConnection.php");
	//require "change_status.php";
	$db_handle = new DBConnection();
	
	header('Access-Control-Allow-Origin: *');
	header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
	header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token');
	header('Content-Type: application/json; charset=UTF-8');
	header('Access-Control-Allow-Credentials: true');
	header('Access-Control-Max-Age: 86400'); 
	
	$request = json_decode($postdata);
	
	$user_id=$request->userId;
	
	$query = "SELECT * FROM `notification` WHERE user_id=$user_id ORDER BY updated_at DESC";
	$res = $db_handle->runQuery($query);

	$query2 = "SELECT timeZone FROM `registration` WHERE id=$user_id";
	$res2 = $db_handle->runQuery($query2);
	$tz=$res2[0];
	$timezone=$tz['timeZone'];

	foreach($res as $key => $value)
		{
			$id= $value['id'];
			$sender_id= $value['sender_id'];
			$user_id= $value['user_id'];
			$msg_id= $value['msg_id'];
			$message= $value['message'];
			$status= $value['status'];
			$starttime= $value['start_time'];
			$endtime= $value['end_time'];
			$date= $value['date']; 

			$a = new DateTime($starttime);
			$b = new DateTime($endtime);
			$c = new DateTime($date);

			$a->setTimezone(new DateTimeZone($timezone));
			$b->setTimezone(new DateTimeZone($timezone));
			$c->setTimezone(new DateTimeZone($timezone));
			
			$x= $a->format('Y-m-d H:i:s');
			$y= $b->format('Y-m-d H:i:s');

			$arr[]=array("id"=>$id,"sender_id"=>$sender_id,"user_id"=>$user_id,"msg_id"=>$msg_id,"message"=>$message,"status"=>$status,"start_time"=>$x,"end_time"=>$y,"date"=>$date);
			
		}
		echo json_encode($arr);
?>