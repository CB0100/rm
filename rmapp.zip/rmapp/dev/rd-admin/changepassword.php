<?php 
 require_once('include/header.php');
 if(!isset($_SESSION)){
    session_start();
    
    }
 require_once('../functions.php');?>
<?php 

if(isset($_POST['old_password']) && isset($_POST['new_password']) && isset($_POST['confirm_password'])){
    $opswd=md5($_POST['old_password']);
    $npswd=$_POST['new_password'];
    $cpswd=$_POST['confirm_password'];
    if($npswd!=$cpswd){
        echo "<script>alert ('New password and confirm password should match')</script>";
        echo "<script> window.location.href = '/rd-admin/changepassword.php';</script>";
    }
    else{
    //$query = "SELECT `adminEmail` FROM `admin` WHERE adminPassword='".$opswd."'";
    $query = "SELECT * FROM `admin` WHERE adminPassword='".$opswd."' AND adminEmail='".$_SESSION['user_name']."'";
    $return_result = $db_handle->runQuery($query);

    if($return_result>0){
        foreach ($return_result as $data) {
            $admin_email = $data['adminEmail'];
        }
        $pass = md5($_POST['new_password']);
        $reg_query = "UPDATE `admin` SET `adminPassword`='".$pass."' WHERE `adminEmail` = '".$admin_email."'";
        $exe_query = $db_handle->updateQuery($reg_query);
        if($exe_query == true){ 
            echo "<script>alert ('Update Successfully')</script>";
            echo "<script> window.location.href = '/rd-admin/dashboard.php';</script>";
        }else{
            echo "<script>alert ('Update Fails')</script>";
            echo "<script> window.location.href = '/rd-admin/changepassword.php';</script>";
        } 
    }
    else{
        echo "<script>alert ('Update Fails')</script>";
        echo "<script> window.location.href = '/rd-admin/changepassword.php';</script>";
    } 
}
}?>

    <div class="wrapper-pro">
      <?php require_once('include/sidebar.php');?>
        <!-- Header top area start-->
        <?php require_once('include/head.php');?>

            <!-- Header top area end-->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 small-dn">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcome-list shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="breadcome-heading">
                                            
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li>
                                                <span class="bread-blod">Change Password</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                 <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">Dashboard</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                        </li>
                                        <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">User</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                            <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                                <a href="addUser.php" class="dropdown-item">Add User</a>
                                                <a href="viewUser.php" class="dropdown-item">View User</a>
                                            </div>
                                        </li>
                                    </ul>
                                </nav>
                                <?php //require_once('include/sidebar.php');?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 des-none">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                            <form role="search" class="">
                                                <input type="text" placeholder="Search..." class="form-control">
                                                <a href=""><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Change Password</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- Register Start-->
            <div class="login-form-area mg-t-30 mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3"></div>
                       
                        <form id="adminpro-register-form" class="adminpro-form" action="" method="post">
                            
                            <div class="col-lg-6">
                                <div class="login-bg">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="logo">
                                                <a href="#"><img src="img/logo/log.png" alt="" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="login-title">
                                                <h1>Change Password</h1>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Old Password</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="password" name="old_password" id="old_password" required/>
                                                <i class="fa fa-lock login-user"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>New Password</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="password" name="new_password" id="new_password" required/>
                                                <i class="fa fa-lock login-user"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p>Confirm Password</p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="password" name="confirm_password" id="confirm_password" required/>
                                                <i class="fa fa-lock login-user"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4"></div>
                                        <div class="col-lg-8">
                                            <div class="login-button-pro">
                                                <button type="submit" class="login-button login-button-lg" id="save">Save</button>
                                                <button type="submit" id="cancel" class="login-button login-button-rg"><a href="dashboard.php">Cancel</a></button>
                                            </div>
                                        </div>
                                    </div>  
                                </div>
                            </div>
                        </form>
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>
            <!-- Register End-->
        </div>
    </div>
    <!-- Footer Start-->
  <?php require_once('include/footer.php');?>
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- form validate JS
        ============================================ -->
    <script src="js/jquery.form.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/form-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="js/main.js"></script>
</body>

</html>