<?php
    require_once ("../api/DbConnection.php");
    $db_handle = new DBConnection();
    $u_id=$_GET['id'];
    $query1 = "DELETE FROM `notification` WHERE id='".$u_id."'";
    
    $res = $db_handle->deleteQuery($query1);
    //echo $res;die();
    echo "deleted successfully";
?>