<?php
    require_once ("../api/DbConnection.php");
    $db_handle = new DBConnection();
    $user_id=$_GET['id'];
    $query1 = "SELECT * FROM `admin` WHERE id=$user_id";
	$res = $db_handle->runQuery($query1);
    $a=$res[0];
?>
<form method="post">
    ID<input type="text" name="t1" value='<?php echo $a['id']; ?>'><br>
    Admin name<input type="text" name="t2" value='<?php echo $a['adminName']; ?>'><br>
    Admin Password<input type="text" name="t3" value='<?php echo $a['adminPassword']; ?>'><br>
    Admin Email<input type="text" name="t4" value='<?php echo $a['adminEmail']; ?>'><br>
    Status<input type="text" name="t5" value='<?php echo $a['status']; ?>'><br>
    Created at<input type="text" name="t6" value='<?php echo $a['created_at']; ?>'><br>
    <input type="submit" value="Update" name="update">
</form>
<?php
    if(isset($_POST['update']))
    {
        $a1 = $_POST['t1'];
        $a2 = $_POST['t2'];
        $a3 = md5($_POST['t3']);
        $a4 = $_POST['t4'];
        $a5 = $_POST['t5'];
        $sql_qry = "UPDATE `admin` SET `adminName`='".$a2."',`adminEmail`='".$a4."',`status`='".$a5."' WHERE `id`=$a1";
        $res = $db_handle->updateQuery($sql_qry);
        if($res == true)
            {
                echo "updated";
            }
        else
            {
                echo "fails";
            }
    }
?>