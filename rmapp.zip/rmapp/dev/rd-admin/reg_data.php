<?php require_once('include/header.php');?>
<?php require_once('../functions.php');?>
<?php
include "all_tables.php";
?>
<?php
$query = "SELECT * FROM `registration`";
$res = $db_handle->runQuery($query);

?>
<style>
table{
    display:table-cell;
}
</style>
<?php
//print_r($res);die();
echo "<table border=2><tr><th>id</th><th>Username</th><th>Fname</th><th>Lname</th><th>User password</th><th>Email</th><th>Status</th><th>Device token</th><th>Created at</th><th>Time zone</th><th>Updated at</th><th>Edit</th><th>Delete</th></tr>";
foreach($res as $re){
    $id=$re["id"];
   $userName = $re["userName"]; 
   $fname=$re["fname"];
   $lname=$re["lname"];
   $password=$re["userPassword"];
   $email=$re["userEmail"];
   $status=$re["status"];
   $device_token=$re["device_token"];
   $created_at=$re["created_at"];
   $timezone=$re["timeZone"];
   $updated_at=$re["updated_at"];
   echo "<tr><td>".$id."</td><td>".$userName."</td><td>".$fname."</td><td>".$lname."</td><td>".$password."</td><td>".$email."</td><td>".$status."</td><td>".$device_token."</td><td>".$created_at."</td><td>".$timezone."</td><td>".$updated_at."</td><td><a href='editreg.php?id=".$email."'>Edit</a></td><td><a href='deletereg.php?id=".$email."'>Delete</a></td></tr>";
}
echo "</table>";
?>