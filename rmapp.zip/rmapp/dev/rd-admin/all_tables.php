<style>
table{
    display:inline-table;
}
</style>
<table>
<tr><td><a href="admin_data.php">Admin</a></td><tr>
<tr><td><a href="login_data.php">Login</a></td><tr>
<tr><td><a href="reg_data.php">Registration</a></td><tr>
<tr><td><a href="noti_data.php">Notification</a></td><tr>
</table>



