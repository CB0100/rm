<div class="footer-copyright-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-copy-right">
                    <p>Copyright &#169; 2018 Codingbrains All rights reserved. Template by <a href="https://colorlib.com">Codingbrains</a>.</p>
                </div>
            </div>
        </div>
    </div>
</div>