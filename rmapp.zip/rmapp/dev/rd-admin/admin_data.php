<?php require_once('include/header.php');?>
<?php require_once('../functions.php');?>
<?php
    include "all_tables.php";
    $query = "SELECT * FROM `admin`";
    $res = $db_handle->runQuery($query);
?>
<style>
    table
        {
            display:inline-table;
        }
</style>
<?php
    echo "<table border=2><tr><th>id</th><th>adminName</th><th>adminEmail</th><th>adminPassword</th><th>status</th><th>created_at</th><th>Edit</th><th>Delete</th></tr>";
    foreach($res as $re)
    {
        $a = $re["id"]; 
        $b=$re["adminName"];
        $c=$re["adminEmail"];
        $d=$re["adminPassword"];
        $e=$re["status"];
        $f=$re["created_at"];
        echo "<tr><td>".$a."</td><td>".$b."</td><td>".$c."</td><td>".$d."</td><td>".$e."</td><td>".$f."</td><td><a href='editadmin.php?id=".$a."' target='_blank'>Edit</a></td><td><a href='deleteadmin.php?id=".$a."'>Delete</a></td></tr>";
    }
    echo "</table>";
?>