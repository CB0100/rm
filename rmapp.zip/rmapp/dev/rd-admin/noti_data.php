<?php require_once('include/header.php');?>

<?php require_once('../functions.php');?>
<?php
include "all_tables.php";
?>
<?php
$query = "SELECT * FROM `notification`";

$res = $db_handle->runQuery($query);

?>
<style>
table{
    display:inline-table;
}
</style>
<?php
//print_r($res);die();
echo "<table border=2><tr><th>id</th><th>sender_id</th><th>user_id</th><th>msg_id</th><th>message</th><th>status</th><th>start_time</th><th>end_time</th><th>date</th><th>Edit</th><th>Delete</th></tr>";
foreach($res as $re){
    $id=$re["id"];
   $a = $re["sender_id"]; 
   $b=$re["user_id"];
   $c=$re["msg_id"];
   $d=$re["message"];
   $e=$re["status"];
   $f=$re["start_time"];
   $g=$re["end_time"];
   $h=$re["date"];
   echo "<tr><td>".$id."</td><td>".$a."</td><td>".$b."</td><td>".$c."</td><td>".$d."</td><td>".$e."</td><td>".$f."</td><td>".$g."</td><td>".$h."</td><td><a href='editnoti.php?id=".$a."'>Edit</a></td><td><a href='deletenoti.php?id=".$id."' target='_blank'>Delete</a></td></tr>";
}
echo "</table>";
?>