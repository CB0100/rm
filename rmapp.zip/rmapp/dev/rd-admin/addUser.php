<?php 
require_once('include/header.php');
if(!isset($_SESSION)){
session_start();

}
require_once('../functions.php');?>
    <div class="wrapper-pro">
      <?php require_once('include/sidebar.php');?>
        <!-- Header top area start-->
        <?php require_once('include/head.php');?>

            <!-- Header top area end-->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 small-dn">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcome-list shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="breadcome-heading">
                                            
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li>
                                                <?php if($_GET['id']){?>
                                                    <span class="bread-blod">Edit User</span>
                                                <?php }else{?>
                                                    <span class="bread-blod">Add User</span>
                                                <?php }?>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
            <div class="mobile-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="mobile-menu">
                                <nav id="dropdown">
                                    <ul class="mobile-menu-nav">
                                        <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">Dashboard</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                        </li>
                                        <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">User</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                            <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                                <a href="addUser.php" class="dropdown-item">Add User</a>
                                                <a href="viewUser.php" class="dropdown-item">View User</a>
                                            </div>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu end -->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 des-none">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <div class="breadcome-heading">
                                            <form role="search" class="">
                                                <input type="text" placeholder="Search..." class="form-control">
                                                <a href=""><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Dashboard</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Breadcome End-->
            <!-- Register Start-->
            <div class="login-form-area mg-t-30 mg-b-15">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3"></div>
                       
                        <form id="adminpro-register-form" class="adminpro-form" action="/addUserApi.php" method="post">
                            
                            <div class="col-lg-6">
                                <div class="login-bg">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="logo">
                                                <a href="#"><img src="img/logo/log.png" alt="" />
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="login-title">
                                                <?php if($_GET['id']){?>
                                                    <h1>Edit User</h1>
                                                <?php }else{?>
                                                    <h1>Add User</h1>
                                                <?php }?>
                                                
                                            </div>
                                        </div>
                                    </div>
                                     <?php 
                                    if(isset($_GET['id'])){
                                        $id = $_GET['id'];
                                        $query = "SELECT * FROM `registration` Where `id`=".$_GET['id'];
                                        $return_result = $db_handle->runQuery($query);
                                        if($return_result){
                                            foreach ($return_result as $data) {?>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <div class="login-input-head">
                                                            <p>Full Name</p>
                                                        </div>
                                                    </div>
                                                    <input type="hidden" name="request_type" value="update">
                                                    <input type="hidden" name="id" value="<?php echo $_GET['id'];?>">
                                                    <div class="col-lg-8">
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="login-input-area register-mg-rt">
                                                                    <input type="text" name="fname" value="<?php echo  $data['fName'];?>" />
                                                                    <i class="fa fa-user login-user"></i>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="login-input-area">
                                                                    <input type="text" name="lname" value="<?php echo  $data['lName'];?>"/>
                                                                    <i class="fa fa-user login-user"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <div class="login-input-head">
                                                            <p>Username</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-8">
                                                        <div class="login-input-area">
                                                            <input type="text" name="username" value="<?php echo  $data['userName'];?>"/>
                                                            <i class="fa fa-user login-user"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-lg-4">
                                                        <div class="login-input-head">
                                                            <p>Email Address</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-8">
                                                        <div class="login-input-area">
                                                            <input type="email" name="email" value="<?php echo  $data['userEmail'];?>"/>
                                                            <i class="fa fa-envelope login-user" aria-hidden="true"></i>
                                                        </div>
                                                    </div>
                                                <div class="row">
                                                    <div class="col-lg-4"></div>
                                                    <div class="col-lg-8">
                                                        <div class="login-button-pro">
                                                        <button type="submit" id="cancel" class="login-button login-button-rg"><a href="dashboard.php">Cancel</a></button>
                                                            <button type="submit" class="login-button login-button-lg">Update</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } 
                                        }
                                    }else{?>
                                          <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="login-input-head">
                                                        <p>Full Name</p>
                                                    </div>
                                                </div>
                                                 <input type="hidden" name="request_type" value="add">
                                                <div class="col-lg-8">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                                            <div class="login-input-area register-mg-rt">
                                                                <input type="text" name="fname" value="" />
                                                                <i class="fa fa-user login-user"></i>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <div class="login-input-area">
                                                                <input type="text" name="lname" />
                                                                <i class="fa fa-user login-user"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="login-input-head">
                                                        <p>Username</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-8">
                                                    <div class="login-input-area">
                                                        <input type="text" name="username" />
                                                        <i class="fa fa-user login-user"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="login-input-head">
                                                        <p>Email Address</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-8">
                                                    <div class="login-input-area">
                                                        <input type="email" name="email" />
                                                        <i class="fa fa-envelope login-user" aria-hidden="true"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="login-input-head">
                                                        <p>Password</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-8">
                                                    <div class="login-input-area">
                                                        <input type="password" name="password" id="password" />
                                                        <i class="fa fa-lock login-user"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4">
                                                    <div class="login-input-head">
                                                        <p>Confirm Password</p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-8">
                                                    <div class="login-input-area">
                                                        <input type="password" name="confarm_password" id="cpswd" />
                                                        <i class="fa fa-lock login-user"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4"></div>
                                                <div class="col-lg-8">
                                                    <div class="login-button-pro">
                                                    <button type="submit" id="cancel" class="login-button login-button-rg"><a href="dashboard.php">Cancel</a></button>
                                                        <button type="submit" class="login-button login-button-lg">Add</button>
                                                    </div>
                                                </div>
                                            </div>  
                                    <?php } ?>
                                   
                                </div>
                            </div>
                        </form>
                        <div class="col-lg-3"></div>
                    </div>
                </div>
            </div>
            <!-- Register End-->
        </div>
    </div>
    <!-- Footer Start-->
  <?php require_once('include/footer.php');?>
    <!-- Footer End-->
    <!-- jquery
        ============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- form validate JS
        ============================================ -->
    <script src="js/jquery.form.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/form-active.js"></script>
    <!-- main JS
        ============================================ -->
    <script src="js/main.js"></script>
</body>

</html>