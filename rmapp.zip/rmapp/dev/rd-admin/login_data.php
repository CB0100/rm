<?php require_once('include/header.php');?>
<?php require_once('../functions.php');?>
<?php
include "all_tables.php";
?>
<?php
$query = "SELECT * FROM `login`";
$res = $db_handle->runQuery($query);
//print_r($res);die();

?>
<style>
table{
    display:inline-table;
}
</style>
<?php	

echo "<table border=2><tr><th>id</th><th>userName</th><th>userEmail</th><th>userPassword</th><th>status</th><th>loginCount</th><th>created_at</th><th>updated_at</th><th>Edit</th><th>Delete</th></tr>";
foreach($res as $re){
   $a = $re["id"]; 
   $b=$re["userName"];
   $c=$re["userEmail"];
   $d=$re["userPassword"];
   $e=$re["status"];
   $f=$re["loginCount"];
   $g=$re["created_at"];
   $h=$re["updated_at"];
   
   echo "<tr><td>".$a."</td><td>".$b."</td><td>".$c."</td><td>".$d."</td><td>".$e."</td><td>".$f."</td><td>".$g."</td><td>".$h."</td><td><a href='editlogin.php?id=".$a."'>Edit</a></td><td><a href='deletelogin.php?id=".$a."'>Delete</a></td></tr>";
}
echo "</table>";
?>