<?php
// ---------------------------------------------------------
 $app_name = "phpJobScheduler";
 $phpJobScheduler_version = "3.9";
// ---------------------------------------------------------

define('DBHOST', '');// database host address - localhost is usually fine

define('DBNAME', 'codingbr_reminderAPIDB');// database name - must already exist
define('DBUSER', 'codingbr_user');// database username - must already exist
define('DBPASS', 'tek69CnKzCGG');// database password for above username

define('DEBUG', true);// set to false when done testing