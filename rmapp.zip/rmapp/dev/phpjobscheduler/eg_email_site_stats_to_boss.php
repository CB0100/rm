<?php 
$msg = "First line of text\nSecond line of text";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);

// send email
mail("codingbrains56@gmail.com","My subject",$msg);      
//echo "<H3>correctly run this file:<br><br>". $_SERVER['PHP_SELF'];
?>
