<?php
include("readme.html");    
?>
