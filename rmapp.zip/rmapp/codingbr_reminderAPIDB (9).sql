-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 22, 2019 at 08:52 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codingbr_reminderAPIDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPassword` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminName`, `adminEmail`, `adminPassword`, `status`, `created_at`) VALUES
(1, 'Rajesh Kr. Gupta', 'codingbrains6@gmail.com', 'e6e061838856bf47e1de730719fb2609', 'logout', '2018-12-12'),
(2, 'ravi vaish', 'codingbrains56@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'logout', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `loginCount` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `userName`, `userEmail`, `userPassword`, `status`, `loginCount`, `created_at`, `updated_at`) VALUES
(99, 'Virat Kohli', 'codingbrains1@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Active', 0, '2019-01-16', '0000-00-00'),
(100, 'James Potter', 'codingbrains2@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Active', 0, '2019-01-16', '0000-00-00'),
(101, 'rajeshkumar', 'codingbrains06@gmail.com', 'ceb6c970658f31504a901b89dcd3e461', 'Active', 0, '2019-01-16', '0000-00-00'),
(102, 'Jack kallis', 'codingbrains3@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'Active', 0, '2019-01-18', '0000-00-00'),
(103, 'Abc', 'Abc@gmail.com', 'c81e728d9d4c2f636f067f89cc14862c', 'Active', 0, '2019-01-19', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(4) NOT NULL,
  `sender_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `msg_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `sender_id`, `user_id`, `msg_id`, `message`, `status`, `start_time`, `end_time`, `updated_at`, `date`) VALUES
(265, 102, 99, '', 'Y2k', 'Pending', '2019-01-22 08:00:00', '2019-01-22 08:30:00', '2019-01-22 13:43:01', '2019-01-22 04:43:30'),
(264, 99, 101, '', 'Please enter your description for Appointment.', 'Pending', '2019-01-22 08:30:00', '2019-01-22 09:00:00', '2019-01-22 13:43:01', '2019-01-22 04:15:09'),
(263, 99, 101, '', '', 'Pending', '2019-01-22 08:00:00', '2019-01-22 08:30:00', '2019-01-22 13:43:01', '2019-01-22 04:14:34'),
(262, 102, 99, '0:1548089640560008%388aa2fe388aa2fe', '', 'Pending', '2019-01-21 10:00:00', '2019-01-21 10:30:00', '2019-01-22 10:52:18', '2019-01-21 10:54:00'),
(261, 99, 102, '0:1548089579031988%388aa2fe388aa2fe', 'Hello my name was I am in my name I was going on my new computer I love to talk and see what you mean by google and I love to check in and check my phone and I just saw the new phone number I just got my new email I just wanted you and your name and ', 'Pending', '2019-01-21 10:00:00', '2019-01-21 10:30:00', '2019-01-22 10:52:18', '2019-01-21 10:52:59'),
(260, 100, 102, '0:1548088683587950%388aa2fe388aa2fe', 'Ok man', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 10:38:03'),
(258, 99, 102, '', 'Hzjzjs', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 13:43:01', '2019-01-21 10:27:25'),
(259, 102, 99, '0:1548088362911282%388aa2fe388aa2fe', 'Testing for tomorrow night to watch ', 'Pending', '2019-01-21 11:30:00', '2019-01-21 12:00:00', '2019-01-22 12:31:58', '2019-01-21 10:32:43'),
(257, 100, 102, '', 'Gshzzh', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 13:43:01', '2019-01-21 10:26:26'),
(255, 99, 100, '', 'Test 1', 'Pending', '2019-01-22 05:00:33', '2019-01-23 05:30:33', '2019-01-22 13:43:01', '2019-01-21 10:05:57'),
(256, 99, 102, '', 'Please enter your description for Appointment.', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 13:43:01', '2019-01-21 10:25:07'),
(253, 99, 100, '', 'Test 1', 'Pending', '2019-01-10 05:00:33', '2019-01-10 05:30:33', '2019-01-22 13:43:01', '2019-01-21 10:05:20'),
(254, 102, 99, '', 'Tests your brain ', 'Pending', '2019-01-21 11:00:00', '2019-01-21 11:30:00', '2019-01-22 13:43:01', '2019-01-21 10:05:29'),
(252, 99, 100, '', 'Test 1', 'Pending', '2019-01-10 05:00:33', '2019-01-10 05:30:33', '2019-01-22 13:43:01', '2019-01-21 10:05:10'),
(251, 100, 99, '', 'Test 1', 'Pending', '2019-01-10 05:00:33', '2019-01-10 05:30:33', '2019-01-22 13:43:01', '2019-01-21 10:04:33'),
(250, 100, 99, '', 'Testing my phone ', 'Pending', '2019-01-21 11:00:00', '2019-01-21 11:30:00', '2019-01-22 13:43:01', '2019-01-21 10:03:18'),
(249, 100, 99, '', 'Please enter your description for Appointment.', 'Pending', '2019-01-21 10:30:00', '2019-01-21 11:00:00', '2019-01-22 13:43:01', '2019-01-21 09:44:20'),
(248, 100, 99, '0:1548084897793947%388aa2fe388aa2fe', 'CFC should ', 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-01-22 10:52:18', '2019-01-21 09:34:58'),
(247, 100, 99, '0:1548084724035017%388aa2fe388aa2fe', 'Please enter your description for Appointment.', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 11:02:40', '2019-01-21 09:32:04'),
(246, 100, 99, '0:1548084490465096%388aa2fe388aa2fe', 'Teen age group ', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 10:52:18', '2019-01-21 09:28:10'),
(245, 100, 99, '0:1548084460129899%388aa2fe388aa2fe', 'This was not one thing ', 'Pending', '2019-01-21 09:00:00', '2019-01-21 09:30:00', '2019-01-22 10:52:18', '2019-01-21 09:27:40'),
(244, 100, 99, '0:1548084386645660%388aa2fe388aa2fe', 'The new version ', 'Pending', '2019-01-21 10:00:00', '2019-01-21 10:30:00', '2019-01-22 10:52:18', '2019-01-21 09:26:26'),
(243, 100, 99, '0:1548084288995608%388aa2fe388aa2fe', 'And if ', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 10:52:18', '2019-01-21 09:24:49'),
(242, 99, 101, '', 'Little game ', 'Pending', '2019-01-21 09:00:00', '2019-01-21 09:30:00', '2019-01-22 13:43:01', '2019-01-21 09:20:45'),
(241, 102, 100, '0:1548078838986578%388aa2fe388aa2fe', 'Prime time mag', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 07:53:59'),
(239, 102, 100, '0:1548078243290744%388aa2fe388aa2fe', 'God', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 07:44:03'),
(240, 102, 100, '0:1548078593331828%388aa2fe388aa2fe', 'Tum pass', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 07:49:53'),
(238, 102, 100, '0:1548078054046234%388aa2fe388aa2fe', 'Remnd me', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 07:40:54'),
(237, 102, 100, '0:1548078006697626%388aa2fe388aa2fe', 'Ok', 'Pending', '2019-01-21 09:00:00', '2019-01-21 09:30:00', '2019-01-22 10:52:18', '2019-01-21 07:40:06'),
(235, 102, 100, '0:1548077935319745%388aa2fe388aa2fe', 'Yuif', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 10:52:18', '2019-01-21 07:38:55'),
(236, 102, 100, '0:1548077945458976%388aa2fe388aa2fe', 'Fjfj', 'Pending', '2019-01-21 09:00:00', '2019-01-21 09:30:00', '2019-01-22 10:52:18', '2019-01-21 07:39:05'),
(234, 102, 100, '0:1548077405891731%388aa2fe388aa2fe', 'Lko', 'Pending', '2019-01-21 11:30:00', '2019-01-21 12:00:00', '2019-01-22 10:52:18', '2019-01-21 07:30:05'),
(232, 102, 100, '0:1548077119052761%388aa2fe388aa2fe', 'Ijhhogh', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 07:25:19'),
(233, 102, 100, '0:1548077272993193%388aa2fe388aa2fe', 'Apo', 'Pending', '2019-01-21 09:30:00', '2019-01-21 10:00:00', '2019-01-22 10:52:18', '2019-01-21 07:27:53'),
(231, 102, 100, '0:1548077067409721%388aa2fe388aa2fe', 'Ucfjf', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 07:24:27'),
(229, 102, 100, '0:1548076901394105%388aa2fe388aa2fe', 'Appp', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 10:52:18', '2019-01-21 07:21:41'),
(230, 102, 100, '', 'Hi kallis', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 13:43:01', '2019-01-21 07:24:08'),
(228, 102, 100, '', 'Hejsj', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 13:43:01', '2019-01-21 07:21:20'),
(226, 100, 102, '', 'Des', 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-01-22 13:43:01', '2019-01-21 07:18:35'),
(227, 100, 102, '0:1548076728984681%388aa2fe388aa2fe', 'Gifhkj', 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-01-22 10:52:18', '2019-01-21 07:18:49'),
(225, 100, 102, '0:1548076693834059%388aa2fe388aa2fe', 'Testing done by Dev', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-21 07:18:14'),
(224, 99, 102, '', 'Testing done by Dev', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-21 07:03:49'),
(222, 99, 100, '', 'Testing done by Dev', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-21 07:02:52'),
(223, 99, 100, '', 'Testing done by Dev', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-21 07:03:28'),
(221, 100, 102, '', 'Des', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 13:43:01', '2019-01-21 06:54:33'),
(219, 102, 100, '', 'Yo', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 13:43:01', '2019-01-21 06:44:21'),
(220, 102, 100, '', 'Uo', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 13:43:01', '2019-01-21 06:45:32'),
(218, 102, 100, '', 'Hi', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 13:43:01', '2019-01-21 06:43:37'),
(217, 102, 100, '0:1548073774245983%388aa2fe388aa2fe', 'Hsbd', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 10:52:18', '2019-01-21 06:29:34'),
(215, 102, 100, '', 'Ufr', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 13:43:01', '2019-01-21 06:22:03'),
(216, 102, 100, '0:1548073774196186%388aa2fe388aa2fe', 'Hsbd', 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-01-22 10:52:18', '2019-01-21 06:29:34'),
(213, 99, 100, '', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-21 04:58:15'),
(214, 99, 100, '0:1548068635901047%388aa2fe388aa2fe', 'Testing done by Dev', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-21 05:03:56'),
(212, 99, 100, '', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-21 04:57:51'),
(210, 100, 102, '', 'Hey man what’s up ', 'Pending', '2019-01-21 08:00:00', '2019-01-21 08:30:00', '2019-01-22 13:43:01', '2019-01-21 04:54:06'),
(211, 102, 100, '', 'Yo man', 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-01-22 13:43:01', '2019-01-21 04:56:20'),
(209, 102, 100, '', 'He potter how are you', 'Pending', '2019-01-21 08:30:00', '2019-01-21 09:00:00', '2019-01-22 13:43:01', '2019-01-21 04:53:04'),
(207, 99, 102, '0:1547836340915492%388aa2fe388aa2fe', 'Heyy', 'Pending', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-01-22 10:52:18', '2019-01-18 12:32:21'),
(208, 99, 100, '0:1547837734461216%388aa2fe388aa2fe', 'Gmc', 'Pending', '2019-01-18 08:00:00', '2019-01-18 08:30:00', '2019-01-22 10:52:18', '2019-01-18 12:55:34'),
(206, 99, 102, '0:1547836312744158%388aa2fe388aa2fe', 'Spiderman', 'Pending', '2019-01-18 08:00:00', '2019-01-18 08:30:00', '2019-01-22 10:52:18', '2019-01-18 12:31:53'),
(205, 102, 99, '0:1547836265773333%1184523f1184523f', 'Batman', 'Pending', '2019-01-18 08:00:00', '2019-01-18 08:30:00', '2019-01-22 10:52:18', '2019-01-18 12:31:05'),
(203, 99, 100, '0:1547833607185827%388aa2fe388aa2fe', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:00', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-18 11:46:48'),
(204, 102, 100, '0:1547835807505671%388aa2fe388aa2fe', 'Don', 'Pending', '2019-01-18 08:00:00', '2019-01-18 08:30:00', '2019-01-22 10:52:18', '2019-01-18 12:23:27'),
(136, 15, 99, '0:1547736031958248%388aa2fe388aa2fe', 'dfsdfsdfds', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-17 08:40:32'),
(202, 99, 102, '0:1547833389794193%388aa2fe388aa2fe', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-18 11:43:09'),
(201, 99, 100, '', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:42:59'),
(199, 99, 100, '', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:42:20'),
(200, 99, 102, '0:1547833361750664%388aa2fe388aa2fe', 'by someone specialxxx', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-18 11:42:41'),
(198, 99, 100, '', 'by someone special', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:42:00'),
(197, 99, 100, '0:1547833306077634%388aa2fe388aa2fe', 'by someone special', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-18 11:41:46'),
(196, 99, 102, '', 'by someone special', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:41:23'),
(194, 99, 102, '', 'by postman11', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:40:48'),
(195, 99, 102, '', 'by postman11', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:40:59'),
(192, 102, 100, '', 'Last msg sent by me', 'Pending', '2019-01-18 08:00:00', '2019-01-18 08:30:00', '2019-01-22 13:43:01', '2019-01-18 11:39:16'),
(193, 99, 102, '', 'by postman', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 13:43:01', '2019-01-18 11:40:27'),
(191, 99, 102, '0:1547832004761539%388aa2fe388aa2fe', 'by postman', 'Pending', '2019-01-02 05:25:33', '2019-01-03 05:25:03', '2019-01-22 10:52:18', '2019-01-18 11:20:05'),
(189, 99, 100, '', 'First msg', 'Pending', '2019-01-18 08:30:00', '2019-01-18 09:00:00', '2019-01-22 13:43:01', '2019-01-18 09:16:38'),
(190, 100, 102, '', 'Hello jack', 'Pending', '2019-01-18 08:00:00', '2019-01-18 08:30:00', '2019-01-22 13:43:01', '2019-01-18 10:18:25'),
(266, 102, 100, '0:1548156622964679%388aa2fe388aa2fe', 'Hhh', 'Pending', '2019-01-22 08:00:00', '2019-01-22 08:30:00', '2019-01-22 11:30:23', '2019-01-22 05:30:23');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `fName` text NOT NULL,
  `lName` text NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `device_token` varchar(400) NOT NULL,
  `created_at` date NOT NULL,
  `timeZone` varchar(20) NOT NULL,
  `updated_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `userName`, `fName`, `lName`, `userPassword`, `userEmail`, `status`, `device_token`, `created_at`, `timeZone`, `updated_at`) VALUES
(99, 'Virat Kohli', '', '', '827ccb0eea8a706c4c34a16891f84e7b', 'codingbrains1@gmail.com', 'Active', '', '2019-01-16', 'America/Chicago', '0000-00-00'),
(100, 'James Potter', '', '', '827ccb0eea8a706c4c34a16891f84e7b', 'codingbrains2@gmail.com', 'Active', 'ct81jffgN84:APA91bHgjeY-0BQ3zF05UFvv1csXrUjJ9-vHVJkH9QVSrkJmobusvBPzTYx8vSOccCPzvJ101dQt_jAXCtyjDBxmjTX0PrqU94lrH29ZH9cNJm-E7RfzCx_EhCpNdoZFnC_yupB_5Bzn', '2019-01-16', 'America/Chicago', '0000-00-00'),
(101, 'rajeshkumar', '', '', 'ceb6c970658f31504a901b89dcd3e461', 'codingbrains06@gmail.com', 'Active', '', '2019-01-16', 'America/Chicago', '0000-00-00'),
(102, 'Jack kallis', '', '', '827ccb0eea8a706c4c34a16891f84e7b', 'codingbrains3@gmail.com', 'Active', 'eNcS8_mXzBQ:APA91bEayzOyNeicuVAcjLBmkOEkL9gYyiBxAcoDtVSEZ59Sj5SjszVNUEb0v0kXQTdqy8IuygX9vzGFpL-V2aL57A7UrwdNoTCutXcY6aSbXSnfJibNM5xkW75XgWMwBYpZNS29YyP7', '2019-01-18', 'America/Chicago', '0000-00-00'),
(103, 'Abc', '', '', 'c81e728d9d4c2f636f067f89cc14862c', 'Abc@gmail.com', 'Active', '', '2019-01-19', 'America/Chicago', '0000-00-00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=267;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
